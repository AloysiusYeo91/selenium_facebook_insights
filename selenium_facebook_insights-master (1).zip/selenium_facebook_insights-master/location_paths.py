export_button_path = "/html/body/div[1]/div[3]/div[1]/div/div[5]/div/div/div[2]/div/div[1]/div[1]/div[2]/a/span"
download_button_path = (
    "/html/body/div[8]/div[2]/div/div/div/div/div[2]/div[2]/div/div/div[2]/div/button"
)

insights_selector_paths = {
    "post": "/html/body/div[8]/div[2]/div/div/div/div/div[2]/div[1]/div[2]/div[1]/div/div[3]/input",
    "page": "/html/body/div[8]/div[2]/div/div/div/div/div[2]/div[1]/div[2]/div[1]/div/div[2]/input",
    "video": "/html/body/div[8]/div[2]/div/div/div/div/div[2]/div[1]/div[2]/div[1]/div/div[4]/input",
}

format_selector_path = "/html/body/div[8]/div[2]/div/div/div/div/div[2]/div[1]/div[2]/div[2]/div[1]/div[1]/div[2]/div/a"
formats_selector_paths = {
    "xls": "/html/body/div[9]/div/div/div/ul/li[1]/a/span/span",
    "csv": "/html/body/div[9]/div/div/div/ul/li[2]/a/span/span",
}
